
# Um site sobre batatas
Trabalho do segundo semestre de Programação Web.
Um site sobre batatas.
Simples assim.

## Afazeres
Conteúdo do site:

 - Todos os tipos de batatas
 - Imagens
 - Receitas
 - Estilização
 - Elementos interativos (ou não)

Jogo de plantação:
 - Loja de upgrades
 - Mais opções para a plantação
 - Acrescentar tipos de batatas e suas respectivas imagens

 Site no geral:

 - Mais elementos para o site
 - Adicionar Back-end
