let sidebarBtn = document.querySelector("#btn"); 

sidebarBtn.addEventListener("click",evt=>{
    document.body.classList.toggle("showbar");
});